#!/usr/bin/env node
console.log("global-cli v2: " + process.argv.slice(2).join(" "));
