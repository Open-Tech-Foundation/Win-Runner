#!/usr/bin/env node
console.log("global-cli v1: " + process.argv.slice(2).join(" "));
